﻿using BAIKIEMTRAGIUAKY.GUI;
using FORM1.BUS;
using FORM2.DAL.SQL.SEVEN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAIKIEMTRAGIUAKY
{
    public partial class Form1 : Form
    {
        private bool isAscending = true;
        private DiaPhuongService _diaPhuongService = new DiaPhuongService();
        private TrangThaiService _trangThaiService = new TrangThaiService(); // ✅ DÙNG SERVICE


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadTrangThai();
        }

        private void LoadData()
        {
            var list = _diaPhuongService.GetAllDiaPhuong();
            dataGridView1.DataSource = list.Select(d => new
            {
                d.MaDP,
                d.TenDP,
                d.SoCaNhiemMoi,
                TrangThai = d.TrangThai?.TenTT ?? "Không xác định"
            }).ToList();
        }

        private void LoadTrangThai()
        {
            var list = _trangThaiService.GetAllTrangThai(); // ✅
            cboTrangThai.DataSource = list;
            cboTrangThai.DisplayMember = "TenTT";
            cboTrangThai.ValueMember = "MaTT";
            cboTrangThai.SelectedIndex = 0;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dataGridView1.Rows[e.RowIndex];
                txtMaDP.Text = row.Cells["MaDP"].Value?.ToString() ?? "";
                txtTenDP.Text = row.Cells["TenDP"].Value?.ToString() ?? "";
                txtSoCaNhiemMoi.Text = row.Cells["SoCaNhiemMoi"].Value?.ToString() ?? "";
                string tenTT = row.Cells["TrangThai"].Value?.ToString() ?? "";

                // ✅ DÙNG _trangThaiService, KHÔNG DÙNG _diaPhuongService
                var selectedTT = _trangThaiService.GetAllTrangThai()
                    .FirstOrDefault(t => t.TenTT == tenTT);

                if (selectedTT != null)
                    cboTrangThai.SelectedValue = selectedTT.MaTT;
                else
                    cboTrangThai.SelectedIndex = -1; // hoặc giữ nguyên
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaDP.Text) ||
                    string.IsNullOrWhiteSpace(txtTenDP.Text) ||
                    string.IsNullOrWhiteSpace(txtSoCaNhiemMoi.Text) ||
                    cboTrangThai.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int soCaNhiemMoi;
                if (!int.TryParse(txtSoCaNhiemMoi.Text, out soCaNhiemMoi) || soCaNhiemMoi < 0)
                {
                    MessageBox.Show("Số ca nhiễm mới phải là số nguyên dương!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var diaPhuong = new DiaPhuong
                {
                    MaDP = txtMaDP.Text.Trim(),
                    TenDP = txtTenDP.Text.Trim(),
                    SoCaNhiemMoi = soCaNhiemMoi,
                    MaTT = Convert.ToInt32(cboTrangThai.SelectedValue)
                };

                if (_diaPhuongService.AddDiaPhuong(diaPhuong))
                {
                    MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Mã địa phương đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaDP.Text))
            {
                MessageBox.Show("Chưa chọn địa phương để sửa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoCaNhiemMoi.Text, out int soCaNhiemMoi) || soCaNhiemMoi < 0)
            {
                MessageBox.Show("Số ca nhiễm mới phải là số nguyên ≥ 0!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cboTrangThai.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn trạng thái!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var existing = _diaPhuongService.GetDiaPhuongByMa(txtMaDP.Text.Trim());
            if (existing == null)
            {
                MessageBox.Show("Không tìm thấy địa phương để cập nhật!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int newMaTT = Convert.ToInt32(cboTrangThai.SelectedValue);
            int oldMaTT = existing.MaTT;

            if (oldMaTT != newMaTT)
            {
                string oldTenTT = existing.TrangThai?.TenTT ?? _trangThaiService.GetTenTrangThai(oldMaTT);
                string newTenTT = _trangThaiService.GetTenTrangThai(newMaTT); // ✅ ĐÃ SỬA

                var result = MessageBox.Show(
                    $"Địa phương có sự thay đổi về trạng thái từ '{oldTenTT}' -> '{newTenTT}'?\nBạn có muốn tiếp tục?",
                    "Xác nhận thay đổi trạng thái",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.No)
                    return;
            }

            var updated = new DiaPhuong
            {
                MaDP = txtMaDP.Text.Trim(),
                TenDP = txtTenDP.Text.Trim(),
                SoCaNhiemMoi = soCaNhiemMoi,
                MaTT = newMaTT
            };

            if (_diaPhuongService.UpdateDiaPhuong(updated))
            {
                MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearFields()
        {
            txtMaDP.Clear();
            txtTenDP.Clear();
            txtSoCaNhiemMoi.Clear();
            cboTrangThai.SelectedIndex = -1;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var list = _diaPhuongService.GetAllDiaPhuong();
            if (isAscending)
            {
                list = list.OrderByDescending(d => d.SoCaNhiemMoi).ToList();
                MessageBox.Show("Đã sắp xếp giảm dần theo số ca nhiễm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                list = list.OrderBy(d => d.SoCaNhiemMoi).ToList();
                MessageBox.Show("Đã sắp xếp tăng dần theo số ca nhiễm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            dataGridView1.DataSource = list.Select(d => new
            {
                d.MaDP,
                d.TenDP,
                d.SoCaNhiemMoi,
                TrangThai = d.TrangThai?.TenTT ?? "Không xác định"
            }).ToList();

            isAscending = !isAscending;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            var list = _diaPhuongService.GetAllDiaPhuong().Where(d => d.MaTT != 1).ToList(); // Không ở trạng thái "Bình thường" (MaTT=1)

            if (list.Count == 0)
            {
                MessageBox.Show("Không có địa phương nào không ở trạng thái 'Bình thường'.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            dataGridView1.DataSource = list.Select(d => new
            {
                d.MaDP,
                d.TenDP,
                d.SoCaNhiemMoi,
                TrangThai = d.TrangThai?.TenTT ?? "Không xác định"
            }).ToList();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            // Giả sử bạn có ReportViewer trong một form khác (ví dụ: frmReport)
            // Hoặc bạn có thể tạo một form mới để hiển thị báo cáo
            MessageBox.Show("Chức năng xuất báo cáo đang được phát triển.\nVui lòng tích hợp ReportViewer sau.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // TODO: Thêm ReportViewer ở đây nếu có
        }

        private void toolStripMenuItem1_Click_1(object sender, EventArgs e)
        {

        }

        private void sắpXếpCaNhiễmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var list = _diaPhuongService.GetAllDiaPhuong();
            if (isAscending)
            {
                list = list.OrderByDescending(d => d.SoCaNhiemMoi).ToList();
                MessageBox.Show("Đã sắp xếp giảm dần theo số ca nhiễm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                list = list.OrderBy(d => d.SoCaNhiemMoi).ToList();
                MessageBox.Show("Đã sắp xếp tăng dần theo số ca nhiễm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            dataGridView1.DataSource = list.Select(d => new
            {
                d.MaDP,
                d.TenDP,
                d.SoCaNhiemMoi,
                TrangThai = d.TrangThai?.TenTT ?? "Không xác định"
            }).ToList();

            isAscending = !isAscending;
        }

        private void toolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
            var list = _diaPhuongService.GetAllDiaPhuong().Where(d => d.MaTT != 1).ToList(); // Không ở trạng thái "Bình thường" (MaTT=1)

            if (list.Count == 0)
            {
                MessageBox.Show("Không có địa phương nào không ở trạng thái 'Bình thường'.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            dataGridView1.DataSource = list.Select(d => new
            {
                d.MaDP,
                d.TenDP,
                d.SoCaNhiemMoi,
                TrangThai = d.TrangThai?.TenTT ?? "Không xác định"
            }).ToList();
        }

        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            var frm = new frmReport();
            frm.ShowDialog(); // hoặc Show() nếu muốn mở nhiều cửa sổ
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
