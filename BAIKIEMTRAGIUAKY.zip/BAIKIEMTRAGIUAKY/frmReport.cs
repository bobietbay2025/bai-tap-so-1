﻿using System;
using System.Linq;
using System.Windows.Forms;
using FORM1.BUS;

namespace BAIKIEMTRAGIUAKY.GUI
{
    public partial class frmReport : Form
    {
        private DiaPhuongService _diaPhuongService = new DiaPhuongService();
        private TrangThaiService _trangThaiService = new TrangThaiService();

        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            LoadTrangThai();
        }

        private void LoadTrangThai()
        {
            var list = _trangThaiService.GetAllTrangThai();
            cboTrangThai.DataSource = list;
            cboTrangThai.DisplayMember = "TenTT";
            cboTrangThai.ValueMember = "MaTT";
            cboTrangThai.SelectedIndex = 0;
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            int maTT = (int)cboTrangThai.SelectedValue;
            string tenTT = cboTrangThai.Text;

            var data = _diaPhuongService.GetAllDiaPhuong()
                .Where(d => d.MaTT == maTT)
                .Select(d => new
                {
                    MaDP = d.MaDP,
                    TenDP = d.TenDP,
                    SoCaNhiemMoi = d.SoCaNhiemMoi,
                    TrangThai = d.TrangThai?.TenTT ?? "Không xác định"
                }).ToList();

            // Cập nhật tiêu đề phụ
            lblSubTitle.Text = $"Tình hình: {tenTT}";

            // Hiển thị dữ liệu
            dataGridView1.DataSource = data;

            if (data.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu cho trạng thái này!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}